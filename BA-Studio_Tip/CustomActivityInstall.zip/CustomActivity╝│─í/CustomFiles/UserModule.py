import sys, os, time
import win32com.client as win32
import win32gui, win32con
import pyautogui, ctypes
import numpy

def gen_certificates(collection, file_in, file_out, visible):
  
  hwp = win32.gencache.EnsureDispatch("HWPFrame.HwpObject")  #아래한글 인스턴스/오브젝트 생성
  hwp.RegisterModule("FilePathCheckDLL", "AutomationModule") #보안모듈 자동승인 -> regedit에서 등록해야 함.

  hwp.Open(file_in,"HWP","forceopen:true")  #파일 열기

  if(visible == True):
    hwp.XHwpWindows.Item(0).Visible = True  #실생중 HWP화면 보이게 함
  else:
    hwp.XHwpWindows.Item(0).Visible = False  #실생중 HWP화면 보이게 함
    
  hwp.MovePos(3)  #문서 끝으로 이동
  page_list = [item for item in hwp.GetFieldList().split('\x02')]
  
  print(page_list)
  #if(visible == 'True'):
    #msgbox = ctypes.windll.user32.MessageBoxW(0, "확인누름 -> 한글자동화를 실행", "한글 자동화 수행", 1)

  data = numpy.array(collection)
  
  if data.ndim == 1:      
    for cnt, field in enumerate(page_list):
      hwp.PutFieldText(f'{field}{{{{{0}}}}}', collection[cnt])
      
  elif data.ndim == 2:    
    hwp.Run('SelectAll') #문서 전체 선택
    hwp.Run('CopyPage')
    hwp.MovePos(3)  #문서 끝으로 이동
    
    num_pages = len(collection)
    counts = list(range(1,num_pages))
    for count in counts:
      hwp.Run('PastePage')
      hwp.MovePos(3)
      time.sleep(0.1) #데모용
    
    pages = list(range(num_pages))
    
    for page in pages:
      for cnt, field in enumerate(page_list):
        hwp.PutFieldText(f'{field}{{{{{page}}}}}', collection[page][cnt])
  else:
    print("Collection corrupted!")
  
  if(file_out.endswith('.pdf')):
    hwp.SaveAs(file_out, 'PDF') #다른이름으로 파일저장  
  else:
    hwp.SaveAs(file_out, 'HWP') #다른이름으로 파일저장  
  
  #hwp.Save() #연 파일 그대로 저장
  
#----- 실행결과 데모용 완료된 문서 페이지 스크롤--------------------------------------------
  if(visible == True):
    wndow = win32gui.GetForegroundWindow()
    win32gui.ShowWindow(wndow, win32con.SW_MAXIMIZE) #화면 확대
  
    hwp.MovePos(2) #문서의 처음으로 이동
    time.sleep(0.25)
  
    if data.ndim >= 2:
      for page in pages:
        time.sleep(0.25)
        pyautogui.keyDown("alt")
        pyautogui.press('pagedown')
        pyautogui.keyUp("alt")
  
    time.sleep(1) #Add buffer time
    
  #hwp.XHwpDocuments.Item(0).Close(isDirty=False)  # 현재문서 닫기
  os.system("taskkill /f /im hwp.exe")

#----------------------------------------------------------------
# Register your custom-functions
#----------------------------------------------------------------  
def register_functions():

    #Add your function name here 
    vars()['gen_certificates'] = gen_certificates
    
    return

#################################################################
# Activate custom-functions. Do not changes!!!
#################################################################

def custom_func(func, *args): 

    if(args[0] != None):
        result = globals()[func](*args)
    else:
        result = globals()[func]()

    return result
#################################################################