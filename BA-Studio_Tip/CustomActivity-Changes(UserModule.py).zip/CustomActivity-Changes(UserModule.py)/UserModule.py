import os, sys
import time
import Parameters, Code
from ast import literal_eval

def baEval(in_string):
    try:
        obj = literal_eval(in_string)
    #except ValueError:
    except:
        try:
            corrected = "\'" + in_string + "\'"
            obj = literal_eval(corrected)
        except:
            obj = in_string
    return obj
        
def CustomActivity(func_name="", arg1="", arg2="", arg3="", arg4="", arg5=""):
    
    func = Parameters.value['func_name']
    arg1 = Parameters.value['arg1']
    arg2 = Parameters.value['arg2']
    arg3 = Parameters.value['arg3']
    arg4 = Parameters.value['arg4']
    arg5 = Parameters.value['arg5']
    
    print(func, arg1, arg2, arg3, arg4, arg5)
    
    Code.register_functions()
        
    if(arg1 == ""):
        print('Number of args is 0')
        result = Code.custom_func(func, None)
    elif(arg2 == ""):
        print('Number of args is 1')
        result = Code.custom_func(func, baEval(arg1))
    elif(arg3 == ""):
        print('Number of args is 2')
        result = Code.custom_func(func, baEval(arg1), baEval(arg2))
    elif(arg4 == ""):
        print('Number of args is 3')
        result = Code.custom_func(func, baEval(arg1), baEval(arg2), baEval(arg3))
    elif(arg5 == ""):
        print('Number of args is 4')
        result = Code.custom_func(func, baEval(arg1), baEval(arg2), baEval(arg3), baEval(arg4))
    else:
        print('Number of args is 5')
        result = Code.custom_func(func, baEval(arg1), baEval(arg2), baEval(arg3), baEval(arg4), baEval(arg5))
    
    return result
